# WebScanPro
Powerful, complex web scanner

# Terms of use
Im not responsible for any of your actions, do not scan your
target without any permission.

# How to use

```
git clone https://github.com/Rayan25062011/WebScanPro
```
```
chmod +x WebScanPro.py
```
```
python3 WebScanPro.py http://example.com/page.php?id=value
```
# About me (json)
```
jq "about_me" aboutme.json
```

# Credits
Credit to: farinap5
